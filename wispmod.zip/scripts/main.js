require('campaign/wisa');

